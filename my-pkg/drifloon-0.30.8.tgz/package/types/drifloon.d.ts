import * as i0 from '@angular/core';
import { Signal, AfterContentInit, OnInit } from '@angular/core';
import { ControlContainer, FormBuilder, FormGroup } from '@angular/forms';
import * as R from 'rxjs';

declare class UiContainer {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiContainer, "ui-container", never, {}, {}, never, ["*"], true, never>;
}

declare class UiTopbar {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiTopbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiTopbar, "ui-topbar", never, {}, {}, never, ["*"], true, never>;
}

type Align$1 = "left" | "right" | "center";
declare class UiItem {
    grow: i0.InputSignal<number | null>;
    textAlign: i0.InputSignal<Align$1 | null>;
    get style(): Partial<CSSStyleDeclaration>;
    protected theStyle(): Record<string, any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiItem, "ui-item", never, { "grow": { "alias": "grow"; "required": false; "isSignal": true; }; "textAlign": { "alias": "textAlign"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class UiDivider {
    transparent: i0.InputSignalWithTransform<boolean, unknown>;
    pad: i0.InputSignalWithTransform<boolean, unknown>;
    theClass(): Record<string, boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiDivider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiDivider, "ui-divider", never, { "transparent": { "alias": "transparent"; "required": false; "isSignal": true; }; "pad": { "alias": "pad"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type Align = "left" | "center" | "right";
declare class UiBox {
    align: i0.InputSignal<Align | null>;
    pad: i0.InputSignalWithTransform<boolean, unknown>;
    protected theStyle: Signal<Partial<CSSStyleDeclaration>>;
    protected theKlass: Signal<{
        pad: boolean;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiBox, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiBox, "ui-box", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; "pad": { "alias": "pad"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class UiDialogBox {
    cancel: i0.OutputEmitterRef<void>;
    ok: i0.OutputEmitterRef<void>;
    submit: i0.OutputEmitterRef<boolean>;
    protected connectCancel(): void;
    protected connectOk(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiDialogBox, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiDialogBox, "ui-dialog-box", never, {}, { "cancel": "cancel"; "ok": "ok"; "submit": "submit"; }, never, never, true, never>;
}

declare class UiForm {
    title: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiForm, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiForm, "ui-form", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class UiFormField implements AfterContentInit {
    private controlContainer;
    private el;
    private control;
    label: i0.InputSignal<string>;
    constructor(controlContainer: ControlContainer | null);
    ngAfterContentInit(): void;
    protected isInputNeedRequire(): boolean;
    protected errorMsg(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiFormField, [{ optional: true; host: true; skipSelf: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiFormField, "ui-form-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface PagerInput {
    page: number;
    size: number;
    count: number;
}
interface PagerResult {
    page: number;
    prevPage: number;
    nextPage: number;
    totalPage: number;
    selectPages: Array<number>;
}
declare class UiPager {
    pager: i0.InputSignal<PagerInput>;
    pageChange: i0.OutputEmitterRef<number>;
    protected pagerResult: i0.Signal<PagerResult>;
    protected connectToPage(page: number): void;
    protected connectSelectChange(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiPager, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiPager, "ui-pager", never, { "pager": { "alias": "pager"; "required": true; "isSignal": true; }; }, { "pageChange": "pageChange"; }, never, never, true, never>;
}

type Suit = "page" | "dialog";
declare class UiSkeleton {
    suit: i0.InputSignal<Suit>;
    theClass(): Record<string, boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiSkeleton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiSkeleton, "ui-skeleton", never, { "suit": { "alias": "suit"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare abstract class MaybeTrait<T> {
    abstract isJust(): boolean;
    abstract map<R>(f: (value: T) => R): MaybeTrait<R>;
    abstract flatMap<R>(f: (value: T) => Maybe<R>): Maybe<R>;
}
declare class Maybe<T> extends MaybeTrait<T> {
    private value;
    static Just<T>(value: T): Maybe<T>;
    static Nothing: Maybe<any>;
    constructor(value: MaybeTrait<T>);
    isJust(): boolean;
    isNothing(): boolean;
    map<R>(f: (value: T) => R): Maybe<R>;
    flatMap<R>(f: (value: T) => Maybe<R>): Maybe<R>;
    unwrap(): T;
    unwrapOr(def: T): T;
    unwrapOrOptional(): T | null;
}

/**
 * 一些动作的中间值，类似Promise的三个状态。
 */
declare class ActionResult<T> {
    private innerValue;
    static Ok<T>(value: T): ActionResult<T>;
    static Pend: ActionResult<any>;
    static map<T, R>(f: (value: T, index: number) => R): R.OperatorFunction<ActionResult<T>, ActionResult<R>>;
    /**
     * {@link R.switchMap | switchMap}一样的效果。
     * 自动`startWith(ActionResult.Pend)`。
     */
    static switchMap<T, O extends R.Observable<any>>(f: (value: T, idx: number) => O): R.OperatorFunction<T, ActionResult<R.ObservedValueOf<O>>>;
    /**
     * {@link R.mergeMap | mergeMap}一样的效果。
     * 见{@link switchMap}
     */
    static mergeMap<T, O extends R.Observable<any>>(f: (value: T, idx: number) => O): R.OperatorFunction<T, ActionResult<R.ObservedValueOf<O>>>;
    static concatMap<T, O extends R.Observable<any>>(f: (value: T, idx: number) => O): R.OperatorFunction<T, ActionResult<R.ObservedValueOf<O>>>;
    static exhaustMap<T, O extends R.Observable<any>>(f: (value: T, idx: number) => O): R.OperatorFunction<T, ActionResult<R.ObservedValueOf<O>>>;
    constructor(innerValue: Maybe<T>);
    isOk(): boolean;
    get value(): T;
}
declare class UiTaskDirective<T> implements OnInit {
    taskFrom: i0.InputSignal<R.Observable<ActionResult<T>>>;
    private container;
    private templateRef;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiTaskDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UiTaskDirective<any>, "[task]", never, { "taskFrom": { "alias": "taskFrom"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class DialogHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogHeader, "dialog-header", never, {}, {}, never, ["*"], true, never>;
}
declare class DialogFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogFooter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogFooter, "dialog-footer", never, {}, {}, never, ["*"], true, never>;
}
declare class UiDialog {
    private dialogRef;
    show(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiDialog, "ui-dialog", never, {}, {}, never, ["*"], true, never>;
}
declare abstract class UiBaseDialog<T, R> {
    private dialogRef;
    private resultSubject;
    private result$;
    protected fb: FormBuilder;
    protected init(_: T): void;
    protected setResult(value: R): void;
    protected setFinalResult(value: R): void;
    show(input: T): R.Observable<R>;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiBaseDialog<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiBaseDialog<any, any>, "ui-base-dialog", never, {}, {}, never, never, true, never>;
}

declare class UiFormDialog {
    title: i0.InputSignal<string>;
    submit: i0.OutputEmitterRef<void>;
    private dialogRef;
    protected isLoad: i0.WritableSignal<boolean>;
    show(): void;
    close(): void;
    setLoad(): void;
    setUnload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiFormDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiFormDialog, "ui-form-dialog", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; }, { "submit": "submit"; }, never, ["dialog-header", "*", "dialog-footer"], true, never>;
}
declare abstract class UiBaseFormDialog<T, R> {
    private dialogRef;
    protected fb: FormBuilder;
    private result;
    private result$;
    abstract fg: FormGroup;
    protected init(_: T): void;
    show(value: T): R.Observable<R>;
    close(): void;
    connectSubmit(): void;
    abstract submit(): R.Observable<R>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiBaseFormDialog<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UiBaseFormDialog<any, any>, "ui-base-form-dialog", never, {}, {}, never, never, true, never>;
}

/**
 * 仿Haskell的Maybe `fmap`函数。
 * @remarks
 * 该函数将`null`、`undefined`视为Nothing，其余为Just。
 *
 * @example
 * ```
 * fmap(1, inc); // 2
 * fmap(0, inc); // 2
 * fmap(null, inc); // null
 * fmap(undefined, inc); // undefined;
 * ```
 * 上述1和0都是正常，会经过`f`(即`inc`)转换，最后得到结果；`null`、`undefined`直接返回本身，不经过`f`。
 *
 * @param value 可能为空的值。
 * @param f 转换函数，只对非空的value进行转换。
 * @returns 经`f`转换后的值。
 */
declare const fmap: <T, R>(value: T | null | undefined, f: (value: T) => R) => R | null | undefined;
/**
 * 类似{@link fmap}，只有`null`是Nothing，其余是Just。
 */
declare const fmapNull: <T, R>(value: T | null, f: (value: T) => R) => R | null;
/**
 * 类似{@link fmap}，只有`undefined`是Nothing，其余是Just。
 */
declare const fmapUndefined: <T, R>(value: T | undefined, f: (value: T) => R) => R | undefined;
/**
 * 该函数一般用于FromGroup的value格式化。
 * 对于不确定*input*是否为空值的情况下，都可以使用该函数进行处理。
 * 处理后的字符串会`trim`过，不会包含多余空格；如果为空字符串，返回`null`。
 *
 * @example
 * ```
 * normalizeString("  hell o "); // "hell o";
 * normalizeString(undefined); // null
 * ```
 */
declare const normalizeString: (input: string | null | undefined) => string | null;

declare const external_d_fmap: typeof fmap;
declare const external_d_fmapNull: typeof fmapNull;
declare const external_d_fmapUndefined: typeof fmapUndefined;
declare const external_d_normalizeString: typeof normalizeString;
declare namespace external_d {
  export {
    external_d_fmap as fmap,
    external_d_fmapNull as fmapNull,
    external_d_fmapUndefined as fmapUndefined,
    external_d_normalizeString as normalizeString,
  };
}

export { ActionResult, DialogFooter, DialogHeader, external_d as Fx, UiBaseDialog, UiBaseFormDialog, UiBox, UiContainer, UiDialog, UiDialogBox, UiDivider, UiForm, UiFormDialog, UiFormField, UiItem, UiPager, UiSkeleton, UiTaskDirective, UiTopbar };
export type { PagerInput };
