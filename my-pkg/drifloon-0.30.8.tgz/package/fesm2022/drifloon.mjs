import * as i0 from '@angular/core';
import { Component, input, HostBinding, booleanAttribute, computed, output, viewChild, Optional, Host, SkipSelf, inject, ViewContainerRef, TemplateRef, Directive, signal } from '@angular/core';
import * as i1 from '@angular/forms';
import { Validators, FormsModule, NG_VALUE_ACCESSOR, FormBuilder } from '@angular/forms';
import * as R from 'rxjs';

class UiContainer {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiContainer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.1", type: UiContainer, isStandalone: true, selector: "ui-container", ngImport: i0, template: "<div class=\"ui container\">\n\t<ng-content />\n</div>\n", styles: [".ui.container{max-width:100%;margin-left:auto;margin-right:auto}@media only screen and (max-width:767.98px){.ui.container{width:99%}}@media only screen and (min-width:768px)and (max-width:991.98px){.ui.container{width:90%}}@media only screen and (min-width:992px){.ui.container{width:80%}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiContainer, decorators: [{
            type: Component,
            args: [{ selector: 'ui-container', imports: [], template: "<div class=\"ui container\">\n\t<ng-content />\n</div>\n", styles: [".ui.container{max-width:100%;margin-left:auto;margin-right:auto}@media only screen and (max-width:767.98px){.ui.container{width:99%}}@media only screen and (min-width:768px)and (max-width:991.98px){.ui.container{width:90%}}@media only screen and (min-width:992px){.ui.container{width:80%}}\n"] }]
        }] });

class UiTopbar {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiTopbar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.1", type: UiTopbar, isStandalone: true, selector: "ui-topbar", ngImport: i0, template: "<div class=\"ui topbar\">\n\t<ng-content />\n</div>\n", styles: [".ui.topbar{display:flex;align-items:center;border-bottom:2px solid deepskyblue;border-image:linear-gradient(to right,#00bfff,#2e8b57) 1}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiTopbar, decorators: [{
            type: Component,
            args: [{ selector: 'ui-topbar', imports: [], template: "<div class=\"ui topbar\">\n\t<ng-content />\n</div>\n", styles: [".ui.topbar{display:flex;align-items:center;border-bottom:2px solid deepskyblue;border-image:linear-gradient(to right,#00bfff,#2e8b57) 1}\n"] }]
        }] });

class CssStyleBuilder {
    css = {};
    set(key, value) {
        this.css[key] = value;
        return this;
    }
    setOptional(key, value) {
        if (value === null || value === undefined) {
            return this;
        }
        return this.set(key, value);
    }
    build() {
        return this.css;
    }
}

class UiItem {
    grow = input(null, { ...(ngDevMode ? { debugName: "grow" } : {}) });
    textAlign = input(null, { ...(ngDevMode ? { debugName: "textAlign" } : {}) });
    get style() {
        let cssBuilder = new CssStyleBuilder();
        cssBuilder.setOptional("flexGrow", this.grow()?.toString());
        cssBuilder.setOptional("textAlign", this.textAlign());
        return cssBuilder.build();
    }
    theStyle() {
        return {
            "flex-grow": this.grow()
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.0.1", type: UiItem, isStandalone: true, selector: "ui-item", inputs: { grow: { classPropertyName: "grow", publicName: "grow", isSignal: true, isRequired: false, transformFunction: null }, textAlign: { classPropertyName: "textAlign", publicName: "textAlign", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "style": "this.style" } }, ngImport: i0, template: "<ng-content />\n", styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiItem, decorators: [{
            type: Component,
            args: [{ selector: 'ui-item', imports: [], template: "<ng-content />\n" }]
        }], propDecorators: { grow: [{ type: i0.Input, args: [{ isSignal: true, alias: "grow", required: false }] }], textAlign: [{ type: i0.Input, args: [{ isSignal: true, alias: "textAlign", required: false }] }], style: [{
                type: HostBinding,
                args: ["style"]
            }] } });

class UiDivider {
    transparent = input(false, { ...(ngDevMode ? { debugName: "transparent" } : {}), transform: booleanAttribute });
    pad = input(false, { ...(ngDevMode ? { debugName: "pad" } : {}), transform: booleanAttribute });
    theClass() {
        return {
            transparent: this.transparent(),
            pad: this.pad()
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiDivider, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.0.1", type: UiDivider, isStandalone: true, selector: "ui-divider", inputs: { transparent: { classPropertyName: "transparent", publicName: "transparent", isSignal: true, isRequired: false, transformFunction: null }, pad: { classPropertyName: "pad", publicName: "pad", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<hr class=\"ui divider\" [class]=\"theClass()\" />\n", styles: [".ui.divider.pad{margin-top:1rem;margin-bottom:1rem}.ui.divider.transparent{border-color:transparent}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiDivider, decorators: [{
            type: Component,
            args: [{ selector: 'ui-divider', imports: [], template: "<hr class=\"ui divider\" [class]=\"theClass()\" />\n", styles: [".ui.divider.pad{margin-top:1rem;margin-bottom:1rem}.ui.divider.transparent{border-color:transparent}\n"] }]
        }], propDecorators: { transparent: [{ type: i0.Input, args: [{ isSignal: true, alias: "transparent", required: false }] }], pad: [{ type: i0.Input, args: [{ isSignal: true, alias: "pad", required: false }] }] } });

class UiBox {
    align = input(null, { ...(ngDevMode ? { debugName: "align" } : {}) });
    pad = input(false, { ...(ngDevMode ? { debugName: "pad" } : {}), transform: booleanAttribute });
    theStyle = computed(() => {
        const builder = new CssStyleBuilder();
        builder.setOptional("justifyContent", this.align());
        return builder.build();
    }, { ...(ngDevMode ? { debugName: "theStyle" } : {}) });
    theKlass = computed(() => {
        return {
            pad: this.pad()
        };
    }, { ...(ngDevMode ? { debugName: "theKlass" } : {}) });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiBox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.0.1", type: UiBox, isStandalone: true, selector: "ui-box", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, pad: { classPropertyName: "pad", publicName: "pad", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"ui box\" [class]=\"theKlass()\" [style]=\"theStyle()\">\n\t<ng-content />\n</div>\n", styles: [".ui.box{display:flex}.ui.box.pad{padding-top:1rem;padding-bottom:1rem}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiBox, decorators: [{
            type: Component,
            args: [{ selector: 'ui-box', imports: [], template: "<div class=\"ui box\" [class]=\"theKlass()\" [style]=\"theStyle()\">\n\t<ng-content />\n</div>\n", styles: [".ui.box{display:flex}.ui.box.pad{padding-top:1rem;padding-bottom:1rem}\n"] }]
        }], propDecorators: { align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }], pad: [{ type: i0.Input, args: [{ isSignal: true, alias: "pad", required: false }] }] } });

class UiDialogBox {
    cancel = output();
    ok = output();
    submit = output();
    connectCancel() {
        this.cancel.emit();
        this.submit.emit(false);
    }
    connectOk() {
        this.ok.emit();
        this.submit.emit(true);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiDialogBox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.1", type: UiDialogBox, isStandalone: true, selector: "ui-dialog-box", outputs: { cancel: "cancel", ok: "ok", submit: "submit" }, ngImport: i0, template: "<ui-box align=\"right\">\n\t<button class=\"button\" (click)=\"connectCancel()\">\u4E0D\u597D</button>\n\t<button class=\"button\" (click)=\"connectOk()\">\u597D</button>\n</ui-box>\n", styles: [".button{margin-left:.2rem}\n"], dependencies: [{ kind: "component", type: UiBox, selector: "ui-box", inputs: ["align", "pad"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiDialogBox, decorators: [{
            type: Component,
            args: [{ selector: "ui-dialog-box", imports: [UiBox], template: "<ui-box align=\"right\">\n\t<button class=\"button\" (click)=\"connectCancel()\">\u4E0D\u597D</button>\n\t<button class=\"button\" (click)=\"connectOk()\">\u597D</button>\n</ui-box>\n", styles: [".button{margin-left:.2rem}\n"] }]
        }], propDecorators: { cancel: [{ type: i0.Output, args: ["cancel"] }], ok: [{ type: i0.Output, args: ["ok"] }], submit: [{ type: i0.Output, args: ["submit"] }] } });

class UiForm {
    title = input("请填写", { ...(ngDevMode ? { debugName: "title" } : {}) });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiForm, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.0.1", type: UiForm, isStandalone: true, selector: "ui-form", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"ui form\">\n\t<fieldset>\n\t\t<legend>{{ title() }}</legend>\n\t\t<div class=\"body\">\n\t\t\t<ng-content />\n\t\t</div>\n\t</fieldset>\n</div>\n", styles: [".ui.field{margin-bottom:1rem}.ui.field.require>label:before{content:\"*\";color:#ff4500}.ui.field .error{font-size:80%;color:#c71585}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiForm, decorators: [{
            type: Component,
            args: [{ selector: 'ui-form', imports: [], template: "<div class=\"ui form\">\n\t<fieldset>\n\t\t<legend>{{ title() }}</legend>\n\t\t<div class=\"body\">\n\t\t\t<ng-content />\n\t\t</div>\n\t</fieldset>\n</div>\n", styles: [".ui.field{margin-bottom:1rem}.ui.field.require>label:before{content:\"*\";color:#ff4500}.ui.field .error{font-size:80%;color:#c71585}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }] } });

class UiFormField {
    controlContainer;
    el = viewChild("el", { ...(ngDevMode ? { debugName: "el" } : {}) });
    control;
    label = input("", { ...(ngDevMode ? { debugName: "label" } : {}) });
    constructor(controlContainer) {
        this.controlContainer = controlContainer;
    }
    ngAfterContentInit() {
        if (!this.controlContainer) {
            return;
        }
        const controlEl = this.el()?.nativeElement?.querySelector("[formControlName]");
        const name = controlEl?.getAttribute("formControlName");
        if (name) {
            const control = this.controlContainer?.control?.get(name);
            if (control) {
                this.control = control;
            }
        }
    }
    isInputNeedRequire() {
        const b = this.control?.hasValidator(Validators.required);
        return b === true;
    }
    errorMsg() {
        if (!this.control) {
            return null;
        }
        if (this.control.valid) {
            return null;
        }
        if (!this.control.dirty) {
            return null;
        }
        if (this.control.hasError("required")) {
            return `${this.label()}未填写！`;
        }
        return `${this.label()}格式不正确！`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiFormField, deps: [{ token: i1.ControlContainer, host: true, optional: true, skipSelf: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.1", type: UiFormField, isStandalone: true, selector: "ui-form-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                multi: true,
                useExisting: UiFormField
            }
        ], viewQueries: [{ propertyName: "el", first: true, predicate: ["el"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"ui field\" [class.require]=\"isInputNeedRequire()\">\n\t<label>{{ label() }}</label>\n\t<div #el class=\"control\">\n\t\t<ng-content />\n\n\t\t@if (errorMsg(); as errMsg) {\n\t\t<div class=\"error\">{{ errMsg }}</div>\n\t\t}\n\t</div>\n</div>\n", styles: [".ui.field{margin-bottom:1rem}.ui.field.require>label:before{content:\"*\";color:#ff4500}.ui.field .error{font-size:80%;color:#c71585}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiFormField, decorators: [{
            type: Component,
            args: [{ selector: "ui-form-field", imports: [FormsModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            multi: true,
                            useExisting: UiFormField
                        }
                    ], template: "<div class=\"ui field\" [class.require]=\"isInputNeedRequire()\">\n\t<label>{{ label() }}</label>\n\t<div #el class=\"control\">\n\t\t<ng-content />\n\n\t\t@if (errorMsg(); as errMsg) {\n\t\t<div class=\"error\">{{ errMsg }}</div>\n\t\t}\n\t</div>\n</div>\n", styles: [".ui.field{margin-bottom:1rem}.ui.field.require>label:before{content:\"*\";color:#ff4500}.ui.field .error{font-size:80%;color:#c71585}\n"] }]
        }], ctorParameters: () => [{ type: i1.ControlContainer, decorators: [{
                    type: Optional
                }, {
                    type: Host
                }, {
                    type: SkipSelf
                }] }], propDecorators: { el: [{ type: i0.ViewChild, args: ["el", { isSignal: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

const range = (start, end) => {
    let xs = [];
    for (let i = start; i <= end; ++i) {
        xs.push(i);
    }
    return xs;
};
class UiPager {
    pager = input.required({ ...(ngDevMode ? { debugName: "pager" } : {}) });
    pageChange = output();
    pagerResult = computed(() => {
        const pager = this.pager();
        const totalPage = Math.max(pager.page, Math.ceil(pager.count / pager.size));
        const prevPage = pager.page - 1;
        const nextPage = pager.page + 1;
        const prevCuror = Math.max(1, pager.page - 4);
        const prevRange = range(prevCuror, pager.page - 1);
        const nextCuror = Math.min(totalPage, pager.page + 4);
        const nextRange = range(pager.page, nextCuror);
        return {
            page: pager.page,
            prevPage,
            nextPage,
            totalPage,
            selectPages: prevRange.concat(nextRange)
        };
    }, { ...(ngDevMode ? { debugName: "pagerResult" } : {}) });
    connectToPage(page) {
        if (this.pagerResult().page === page) {
            // 同一页。
            return;
        }
        else if (page < 1) {
            alert("已经到第一页了。");
            return;
        }
        else if (page > this.pagerResult().totalPage) {
            alert("已经到最后一页了。");
            return;
        }
        else {
            this.pageChange.emit(page);
        }
    }
    connectSelectChange(event) {
        const el = event.target;
        const value = parseInt(el.value);
        this.connectToPage(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiPager, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.1", type: UiPager, isStandalone: true, selector: "ui-pager", inputs: { pager: { classPropertyName: "pager", publicName: "pager", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { pageChange: "pageChange" }, ngImport: i0, template: "<div class=\"ui pager\">\n\t<button class=\"button\" (click)=\"connectToPage(1)\">\u7B2C\u4E00\u9875</button>\n\t<button class=\"button\" (click)=\"connectToPage(pagerResult().prevPage)\">\u4E0A\u4E00\u9875</button>\n\t<select class=\"selection\" [value]=\"pagerResult().page\" (change)=\"connectSelectChange($event)\">\n\t\t@for (page of pagerResult().selectPages; track page) {\n\t\t<option [selected]=\"pagerResult().page === page\" [value]=\"page\">\u7B2C{{ page }}\u9875</option>\n\t\t}\n\t</select>\n\t<button class=\"button\" (click)=\"connectToPage(pagerResult().nextPage)\">\u4E0B\u4E00\u9875</button>\n\t<button class=\"button\" (click)=\"connectToPage(pagerResult().totalPage)\">\u6700\u540E\u9875</button>\n</div>\n", styles: [".ui.pager{display:flex;justify-content:center}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiPager, decorators: [{
            type: Component,
            args: [{ selector: 'ui-pager', imports: [], template: "<div class=\"ui pager\">\n\t<button class=\"button\" (click)=\"connectToPage(1)\">\u7B2C\u4E00\u9875</button>\n\t<button class=\"button\" (click)=\"connectToPage(pagerResult().prevPage)\">\u4E0A\u4E00\u9875</button>\n\t<select class=\"selection\" [value]=\"pagerResult().page\" (change)=\"connectSelectChange($event)\">\n\t\t@for (page of pagerResult().selectPages; track page) {\n\t\t<option [selected]=\"pagerResult().page === page\" [value]=\"page\">\u7B2C{{ page }}\u9875</option>\n\t\t}\n\t</select>\n\t<button class=\"button\" (click)=\"connectToPage(pagerResult().nextPage)\">\u4E0B\u4E00\u9875</button>\n\t<button class=\"button\" (click)=\"connectToPage(pagerResult().totalPage)\">\u6700\u540E\u9875</button>\n</div>\n", styles: [".ui.pager{display:flex;justify-content:center}\n"] }]
        }], propDecorators: { pager: [{ type: i0.Input, args: [{ isSignal: true, alias: "pager", required: true }] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }] } });

class UiSkeleton {
    suit = input("page", { ...(ngDevMode ? { debugName: "suit" } : {}) });
    theClass() {
        return {
            page: this.suit() === "page",
            dialog: this.suit() === "dialog"
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiSkeleton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.1", type: UiSkeleton, isStandalone: true, selector: "ui-skeleton", inputs: { suit: { classPropertyName: "suit", publicName: "suit", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"ui skeleton\" aria-busy=\"true\" [class]=\"theClass()\">\n\t@if (suit() === \"page\") {\n\t<div>\u6B63\u5728\u52A0\u8F7D\u2026\u2026</div>\n\t}\n\n\t<progress></progress>\n</div>\n", styles: [".ui.skeleton{display:flex;border:4px double dodgerblue;justify-content:center;align-items:center;flex-direction:column}.ui.skeleton.page{min-height:10rem}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiSkeleton, decorators: [{
            type: Component,
            args: [{ selector: 'ui-skeleton', imports: [], template: "<div class=\"ui skeleton\" aria-busy=\"true\" [class]=\"theClass()\">\n\t@if (suit() === \"page\") {\n\t<div>\u6B63\u5728\u52A0\u8F7D\u2026\u2026</div>\n\t}\n\n\t<progress></progress>\n</div>\n", styles: [".ui.skeleton{display:flex;border:4px double dodgerblue;justify-content:center;align-items:center;flex-direction:column}.ui.skeleton.page{min-height:10rem}\n"] }]
        }], propDecorators: { suit: [{ type: i0.Input, args: [{ isSignal: true, alias: "suit", required: false }] }] } });

class MaybeTrait {
}
class Just extends MaybeTrait {
    value;
    tag = "Just";
    constructor(value) {
        super();
        this.value = value;
    }
    isJust() {
        return true;
    }
    map(f) {
        return new Just(f(this.value));
    }
    flatMap(f) {
        return f(this.value);
    }
}
class Nothing extends MaybeTrait {
    tag = "Nothing";
    static Nothing = new Nothing;
    isJust() {
        return false;
    }
    map(_) {
        return Nothing.Nothing;
    }
    flatMap(_) {
        return Maybe.Nothing;
    }
}
class Maybe extends MaybeTrait {
    value;
    static Just(value) {
        return new Maybe(new Just(value));
    }
    static Nothing = new Maybe(Nothing.Nothing);
    constructor(value) {
        super();
        this.value = value;
    }
    isJust() {
        return this.value.isJust();
    }
    isNothing() {
        return !this.isJust();
    }
    map(f) {
        return new Maybe(this.value.map(f));
    }
    flatMap(f) {
        return this.value.flatMap(f);
    }
    unwrap() {
        if (this.value instanceof Just) {
            return this.value.value;
        }
        throw new Error("尝试从Nothing取值！");
    }
    unwrapOr(def) {
        if (this.value instanceof Just) {
            return this.value.value;
        }
        return def;
    }
    unwrapOrOptional() {
        if (this.value instanceof Just) {
            return this.value.value;
        }
        return null;
    }
}

/**
 * 一些动作的中间值，类似Promise的三个状态。
 */
class ActionResult {
    innerValue;
    static Ok(value) {
        return new ActionResult(Maybe.Just(value));
    }
    static Pend = new ActionResult(Maybe.Nothing);
    static map(f) {
        return source => source.pipe(R.map((value, idx) => {
            const v = value.innerValue.map(v => f(v, idx));
            return new ActionResult(v);
        }));
    }
    /**
     * {@link R.switchMap | switchMap}一样的效果。
     * 自动`startWith(ActionResult.Pend)`。
     */
    static switchMap(f) {
        return source => source.pipe(R.switchMap((item, idx) => {
            return f(item, idx).pipe(R.map(ActionResult.Ok), R.startWith(ActionResult.Pend));
        }));
    }
    /**
     * {@link R.mergeMap | mergeMap}一样的效果。
     * 见{@link switchMap}
     */
    static mergeMap(f) {
        return source => source.pipe(R.mergeMap((item, idx) => {
            return f(item, idx).pipe(R.map(ActionResult.Ok), R.startWith(ActionResult.Pend));
        }));
    }
    static concatMap(f) {
        return source => source.pipe(R.concatMap((item, idx) => {
            return f(item, idx).pipe(R.map(ActionResult.Ok), R.startWith(ActionResult.Pend));
        }));
    }
    static exhaustMap(f) {
        return source => source.pipe(R.exhaustMap((item, idx) => {
            return f(item, idx).pipe(R.map(ActionResult.Ok), R.startWith(ActionResult.Pend));
        }));
    }
    constructor(innerValue) {
        this.innerValue = innerValue;
    }
    isOk() {
        return this.innerValue.isJust();
    }
    get value() {
        return this.innerValue.unwrap();
    }
}
class UiTaskDirective {
    taskFrom = input.required({ ...(ngDevMode ? { debugName: "taskFrom" } : {}) });
    container = inject(ViewContainerRef);
    templateRef = inject(TemplateRef);
    ngOnInit() {
        this.taskFrom()
            .subscribe(value => {
            this.container.clear();
            if (!value.isOk()) {
                this.container.createComponent(UiSkeleton);
                return;
            }
            this.container.createEmbeddedView(this.templateRef, {
                $implicit: value.value
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiTaskDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.0.1", type: UiTaskDirective, isStandalone: true, selector: "[task]", inputs: { taskFrom: { classPropertyName: "taskFrom", publicName: "taskFrom", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiTaskDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: "[task]"
                }]
        }], propDecorators: { taskFrom: [{ type: i0.Input, args: [{ isSignal: true, alias: "taskFrom", required: true }] }] } });

class DialogHeader {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: DialogHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.1", type: DialogHeader, isStandalone: true, selector: "dialog-header", ngImport: i0, template: "<ng-content />", isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: DialogHeader, decorators: [{
            type: Component,
            args: [{
                    selector: "dialog-header",
                    template: "<ng-content />"
                }]
        }] });
class DialogFooter {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: DialogFooter, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.1", type: DialogFooter, isStandalone: true, selector: "dialog-footer", ngImport: i0, template: "<ng-content />", isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: DialogFooter, decorators: [{
            type: Component,
            args: [{
                    selector: "dialog-footer",
                    template: "<ng-content />"
                }]
        }] });
class UiDialog {
    dialogRef = viewChild("dialog", { ...(ngDevMode ? { debugName: "dialogRef" } : {}) });
    show() {
        this.dialogRef()?.nativeElement.showModal();
    }
    close() {
        this.dialogRef()?.nativeElement.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.0.1", type: UiDialog, isStandalone: true, selector: "ui-dialog", viewQueries: [{ propertyName: "dialogRef", first: true, predicate: ["dialog"], descendants: true, isSignal: true }], ngImport: i0, template: "<dialog #dialog class=\"ui dialog\">\n\t<ng-content />\n</dialog>\n", styles: [".ui.dialog::backdrop{-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiDialog, decorators: [{
            type: Component,
            args: [{ selector: 'ui-dialog', imports: [], template: "<dialog #dialog class=\"ui dialog\">\n\t<ng-content />\n</dialog>\n", styles: [".ui.dialog::backdrop{-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}\n"] }]
        }], propDecorators: { dialogRef: [{ type: i0.ViewChild, args: ["dialog", { isSignal: true }] }] } });
class UiBaseDialog {
    dialogRef = viewChild(UiDialog, { ...(ngDevMode ? { debugName: "dialogRef" } : {}) });
    resultSubject = new R.Subject();
    result$ = this.resultSubject.asObservable();
    fb = inject(FormBuilder);
    init(_) { }
    setResult(value) {
        this.resultSubject.next(value);
    }
    setFinalResult(value) {
        this.setResult(value);
        this.close();
    }
    show(input) {
        this.init(input);
        this.dialogRef()?.show();
        return this.result$;
    }
    close() {
        this.dialogRef()?.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiBaseDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.0.1", type: UiBaseDialog, isStandalone: true, selector: "ui-base-dialog", viewQueries: [{ propertyName: "dialogRef", first: true, predicate: UiDialog, descendants: true, isSignal: true }], ngImport: i0, template: "", isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiBaseDialog, decorators: [{
            type: Component,
            args: [{
                    selector: "ui-base-dialog",
                    template: ""
                }]
        }], propDecorators: { dialogRef: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UiDialog), { isSignal: true }] }] } });

class UiFormDialog {
    title = input("请填写", { ...(ngDevMode ? { debugName: "title" } : {}) });
    submit = output();
    dialogRef = viewChild.required(UiDialog);
    isLoad = signal(false, { ...(ngDevMode ? { debugName: "isLoad" } : {}) });
    show() {
        this.dialogRef().show();
    }
    close() {
        this.dialogRef().close();
    }
    setLoad() {
        this.isLoad.set(true);
    }
    setUnload() {
        this.isLoad.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiFormDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.1", type: UiFormDialog, isStandalone: true, selector: "ui-form-dialog", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { submit: "submit" }, viewQueries: [{ propertyName: "dialogRef", first: true, predicate: UiDialog, descendants: true, isSignal: true }], ngImport: i0, template: "<ui-dialog>\n\t<ng-content select=\"dialog-header\" />\n\n\t<ui-form [title]=\"title()\">\n\t\t<ng-content />\n\t</ui-form>\n\n\t<ng-content select=\"dialog-footer\" />\n\n\t@if (isLoad()) {\n\t<ui-skeleton suit=\"dialog\" />\n\t}\n\t@else {\n\t<ui-dialog-box (cancel)=\"close()\" (ok)=\"submit.emit()\" />\n\t}\n</ui-dialog>\n", dependencies: [{ kind: "component", type: UiDialog, selector: "ui-dialog" }, { kind: "component", type: UiDialogBox, selector: "ui-dialog-box", outputs: ["cancel", "ok", "submit"] }, { kind: "component", type: UiForm, selector: "ui-form", inputs: ["title"] }, { kind: "component", type: UiSkeleton, selector: "ui-skeleton", inputs: ["suit"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiFormDialog, decorators: [{
            type: Component,
            args: [{ selector: "ui-form-dialog", imports: [
                        UiDialog,
                        UiDialogBox,
                        UiForm,
                        UiSkeleton
                    ], template: "<ui-dialog>\n\t<ng-content select=\"dialog-header\" />\n\n\t<ui-form [title]=\"title()\">\n\t\t<ng-content />\n\t</ui-form>\n\n\t<ng-content select=\"dialog-footer\" />\n\n\t@if (isLoad()) {\n\t<ui-skeleton suit=\"dialog\" />\n\t}\n\t@else {\n\t<ui-dialog-box (cancel)=\"close()\" (ok)=\"submit.emit()\" />\n\t}\n</ui-dialog>\n" }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], submit: [{ type: i0.Output, args: ["submit"] }], dialogRef: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UiDialog), { isSignal: true }] }] } });
class UiBaseFormDialog {
    dialogRef = viewChild(UiFormDialog, { ...(ngDevMode ? { debugName: "dialogRef" } : {}) });
    fb = inject(FormBuilder);
    result = new R.Subject();
    result$ = this.result.asObservable();
    init(_) { }
    show(value) {
        this.init(value);
        this.dialogRef()?.show();
        return this.result$;
    }
    close() {
        this.dialogRef()?.close();
    }
    connectSubmit() {
        this.fg.markAllAsDirty();
        if (this.fg.invalid) {
            return;
        }
        this.dialogRef()?.setLoad();
        this.submit()
            .pipe(R.finalize(() => this.dialogRef()?.setUnload()))
            .subscribe(value => {
            this.result.next(value);
            this.dialogRef()?.setUnload();
            this.dialogRef()?.close();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiBaseFormDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.0.1", type: UiBaseFormDialog, isStandalone: true, selector: "ui-base-form-dialog", viewQueries: [{ propertyName: "dialogRef", first: true, predicate: UiFormDialog, descendants: true, isSignal: true }], ngImport: i0, template: "", isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.1", ngImport: i0, type: UiBaseFormDialog, decorators: [{
            type: Component,
            args: [{
                    selector: "ui-base-form-dialog",
                    template: ""
                }]
        }], propDecorators: { dialogRef: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UiFormDialog), { isSignal: true }] }] } });

/**
 * 仿Haskell的Maybe `fmap`函数。
 * @remarks
 * 该函数将`null`、`undefined`视为Nothing，其余为Just。
 *
 * @example
 * ```
 * fmap(1, inc); // 2
 * fmap(0, inc); // 2
 * fmap(null, inc); // null
 * fmap(undefined, inc); // undefined;
 * ```
 * 上述1和0都是正常，会经过`f`(即`inc`)转换，最后得到结果；`null`、`undefined`直接返回本身，不经过`f`。
 *
 * @param value 可能为空的值。
 * @param f 转换函数，只对非空的value进行转换。
 * @returns 经`f`转换后的值。
 */
const fmap = (value, f) => {
    if (value === null) {
        return null;
    }
    else if (value === undefined) {
        return undefined;
    }
    return f(value);
};
/**
 * 类似{@link fmap}，只有`null`是Nothing，其余是Just。
 */
const fmapNull = (value, f) => {
    if (value === null) {
        return null;
    }
    return f(value);
};
/**
 * 类似{@link fmap}，只有`undefined`是Nothing，其余是Just。
 */
const fmapUndefined = (value, f) => {
    if (value === undefined) {
        return undefined;
    }
    return f(value);
};
/**
 * 该函数一般用于FromGroup的value格式化。
 * 对于不确定*input*是否为空值的情况下，都可以使用该函数进行处理。
 * 处理后的字符串会`trim`过，不会包含多余空格；如果为空字符串，返回`null`。
 *
 * @example
 * ```
 * normalizeString("  hell o "); // "hell o";
 * normalizeString(undefined); // null
 * ```
 */
const normalizeString = (input) => {
    if (input === null || input === undefined) {
        return null;
    }
    const s = input.trim();
    if (s.length === 0) {
        return null;
    }
    return s;
};

var external = /*#__PURE__*/Object.freeze({
    __proto__: null,
    fmap: fmap,
    fmapNull: fmapNull,
    fmapUndefined: fmapUndefined,
    normalizeString: normalizeString
});

/**
 * Generated bundle index. Do not edit.
 */

export { ActionResult, DialogFooter, DialogHeader, external as Fx, UiBaseDialog, UiBaseFormDialog, UiBox, UiContainer, UiDialog, UiDialogBox, UiDivider, UiForm, UiFormDialog, UiFormField, UiItem, UiPager, UiSkeleton, UiTaskDirective, UiTopbar };
//# sourceMappingURL=drifloon.mjs.map
